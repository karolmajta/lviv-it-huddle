var canvasWidth;
var canvasHeight;
var textX;
var textY;

function setup() {
  var parent = document.getElementById('game-container');
  canvasWidth = parent.clientWidth;
  canvasHeight = parent.clientHeight;
  var canvas = createCanvas(canvasWidth, canvasHeight);
  canvas.parent('game-container');
  textX = canvasWidth/2;
  textY = canvasHeight/2;
}

function draw()
{
    background(255, 255, 255);
    fill(0, 0, 0);
    textSize(50);
    textAlign(CENTER, CENTER);
    text("Hello Lviv", textX, textY);
}
